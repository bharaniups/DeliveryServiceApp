﻿namespace DeliveryService.Application;

public class Class1
{

}
