﻿namespace DeliveryService.Domain;

public class Class1
{

}
